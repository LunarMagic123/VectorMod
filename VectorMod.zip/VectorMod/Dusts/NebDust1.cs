using Terraria.ModLoader;

namespace VectorMod.Dusts
{
	public class NebDust1 : ModDust
	{
	}
}