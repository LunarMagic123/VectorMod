using Terraria.ModLoader;

namespace VectorMod.Items
{
	public class ShroomGroupIcon : ModItem
	{
		public override void SetDefaults()
		{
			item.width = 50;
			item.height = 42;
		}
	}
}